"use server"

import { createClient } from "@/utils/supabase/server"
import { cookies } from "next/headers"
import { revalidatePath } from "next/cache"
import { redirect } from "next/navigation"

export async function addTradingRecord(formData: FormData) {
  const supabase = await createClient(cookies)

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/login")
  }

  const profitLossValue = formData.get("profit_loss") as string
  const jumlahLotValue = formData.get("jumlah_lot") as string
  const hargaEntryValue = formData.get("harga_entry") as string
  const hargaExitValue = formData.get("harga_exit") as string

  const tradingData = {
    user_id: user.id,
    tanggal: formData.get("tanggal") as string,
    kategori: formData.get("kategori") as string,
    symbol: (formData.get("symbol") as string) || null,
    tipe_trade: (formData.get("tipe_trade") as string) || null,
    jumlah_lot: jumlahLotValue ? Number.parseInt(jumlahLotValue) : null,
    harga_entry: hargaEntryValue ? Number.parseFloat(hargaEntryValue) : null,
    harga_exit: hargaExitValue ? Number.parseFloat(hargaExitValue) : null,
    profit_loss: Number.parseFloat(profitLossValue),
    catatan: (formData.get("catatan") as string) || null,
    created_at: new Date().toISOString(),
  }

  const { error } = await supabase.from("trading_records").insert([tradingData])

  if (error) {
    console.error("Error inserting trading record:", error)
    redirect("/dashboard?error=" + encodeURIComponent("Failed to save trading data"))
  }

  revalidatePath("/dashboard")
  redirect("/dashboard?success=" + encodeURIComponent("Trading data saved successfully"))
}

export async function getTradingRecords() {
  const supabase = await createClient(cookies)

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    return { data: [], error: "User not authenticated" }
  }

  const { data, error } = await supabase
    .from("trading_records")
    .select("*")
    .eq("user_id", user.id)
    .order("tanggal", { ascending: false })
    .order("created_at", { ascending: false })

  if (error) {
    console.error("Error fetching trading records:", error)
    return { data: [], error: "Failed to fetch trading records" }
  }

  return { data: data || [], error: null }
}

export async function getTradingSummary() {
  const supabase = await createClient(cookies)

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    return { summary: null, error: "User not authenticated" }
  }

  const { data, error } = await supabase
    .from("trading_records")
    .select("kategori, profit_loss, tanggal")
    .eq("user_id", user.id)

  if (error) {
    console.error("Error fetching trading summary:", error)
    return { summary: null, error: error.message }
  }

  if (!data || data.length === 0) {
    return {
      summary: {
        byCategory: {},
        totalProfit: 0,
        totalLoss: 0,
        netProfitLoss: 0,
        totalTrades: 0,
        winRate: 0,
        avgWin: 0,
        avgLoss: 0,
      },
      error: null,
    }
  }

  // Calculate summary by category
  const byCategory = data.reduce((acc: any, record: any) => {
    const kategori = record.kategori
    const profitLoss = Number.parseFloat(record.profit_loss) || 0

    if (!acc[kategori]) {
      acc[kategori] = { total: 0, count: 0, profit: 0, loss: 0 }
    }

    acc[kategori].total += profitLoss
    acc[kategori].count += 1

    if (profitLoss > 0) {
      acc[kategori].profit += profitLoss
    } else {
      acc[kategori].loss += profitLoss
    }

    return acc
  }, {})

  // Calculate overall totals
  const totalProfit = data
    .filter((record: any) => Number.parseFloat(record.profit_loss) > 0)
    .reduce((sum: number, record: any) => sum + (Number.parseFloat(record.profit_loss) || 0), 0)

  const totalLoss = data
    .filter((record: any) => Number.parseFloat(record.profit_loss) < 0)
    .reduce((sum: number, record: any) => sum + (Number.parseFloat(record.profit_loss) || 0), 0)

  const netProfitLoss = totalProfit + totalLoss

  // Calculate win rate
  const winningTrades = data.filter((record: any) => Number.parseFloat(record.profit_loss) > 0).length
  const losingTrades = data.filter((record: any) => Number.parseFloat(record.profit_loss) < 0).length
  const winRate = data.length > 0 ? (winningTrades / data.length) * 100 : 0

  // Calculate average win/loss
  const avgWin = winningTrades > 0 ? totalProfit / winningTrades : 0
  const avgLoss = losingTrades > 0 ? Math.abs(totalLoss / losingTrades) : 0

  return {
    summary: {
      byCategory,
      totalProfit,
      totalLoss,
      netProfitLoss,
      totalTrades: data.length,
      winRate: Math.round(winRate * 100) / 100,
      avgWin: Math.round(avgWin * 100) / 100,
      avgLoss: Math.round(avgLoss * 100) / 100,
      winningTrades,
      losingTrades,
    },
    error: null,
  }
}

export async function deleteTradingRecord(recordId: string) {
  const supabase = await createClient(cookies)

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/login")
  }

  const { error } = await supabase.from("trading_records").delete().eq("id", recordId).eq("user_id", user.id)

  if (error) {
    console.error("Error deleting trading record:", error)
    redirect("/dashboard?error=" + encodeURIComponent("Failed to delete trading record"))
  }

  revalidatePath("/dashboard")
  redirect("/dashboard?success=" + encodeURIComponent("Trading record deleted successfully"))
}

export async function updateTradingRecord(recordId: string, formData: FormData) {
  const supabase = await createClient(cookies)

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/login")
  }

  const profitLossValue = formData.get("profit_loss") as string
  const jumlahLotValue = formData.get("jumlah_lot") as string
  const hargaEntryValue = formData.get("harga_entry") as string
  const hargaExitValue = formData.get("harga_exit") as string

  const updateData = {
    tanggal: formData.get("tanggal") as string,
    kategori: formData.get("kategori") as string,
    symbol: (formData.get("symbol") as string) || null,
    tipe_trade: (formData.get("tipe_trade") as string) || null,
    jumlah_lot: jumlahLotValue ? Number.parseInt(jumlahLotValue) : null,
    harga_entry: hargaEntryValue ? Number.parseFloat(hargaEntryValue) : null,
    harga_exit: hargaExitValue ? Number.parseFloat(hargaExitValue) : null,
    profit_loss: Number.parseFloat(profitLossValue),
    catatan: (formData.get("catatan") as string) || null,
    updated_at: new Date().toISOString(),
  }

  const { error } = await supabase.from("trading_records").update(updateData).eq("id", recordId).eq("user_id", user.id)

  if (error) {
    console.error("Error updating trading record:", error)
    redirect("/dashboard?error=" + encodeURIComponent("Failed to update trading record"))
  }

  revalidatePath("/dashboard")
  redirect("/dashboard?success=" + encodeURIComponent("Trading record updated successfully"))
}
