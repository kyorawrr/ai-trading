"use server"

import { createClient } from "@/utils/supabase/server"
import { redirect } from "next/navigation"
import { revalidatePath } from "next/cache"
import { cookies } from "next/headers"

export async function login(formData: FormData) {
  const supabase = await createClient(cookies)
  const email = formData.get("email") as string
  const password = formData.get("password") as string

  if (!email || !password) {
    redirect("/login?error=" + encodeURIComponent("Email dan password harus diisi"))
  }

  const { error } = await supabase.auth.signInWithPassword({ email, password })

  if (error) {
    redirect("/login?error=" + encodeURIComponent(error.message))
  }

  revalidatePath("/", "layout")
  redirect("/dashboard")
}

export async function signup(formData: FormData) {
  const supabase = await createClient(cookies)
  const email = formData.get("email") as string
  const password = formData.get("password") as string

  if (!email || !password) {
    redirect("/login?error=" + encodeURIComponent("Email dan password harus diisi"))
  }

  if (password.length < 6) {
    redirect("/login?error=" + encodeURIComponent("Password minimal 6 karakter"))
  }

  const { error } = await supabase.auth.signUp({
    email,
    password,
    options: {
      emailRedirectTo: `${process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000"}/auth/confirm`,
    },
  })

  if (error) {
    redirect("/login?error=" + encodeURIComponent(error.message))
  }

  revalidatePath("/", "layout")
  redirect(
    "/login?message=" +
      encodeURIComponent("Cek email kamu untuk link konfirmasi. Klik link tersebut untuk mengaktifkan akun."),
  )
}

export async function signout() {
  const supabase = await createClient(cookies)
  await supabase.auth.signOut()
  revalidatePath("/", "layout")
  redirect("/login")
}

export async function resendConfirmation(formData: FormData) {
  const supabase = await createClient(cookies)
  const email = formData.get("email") as string

  if (!email) {
    redirect("/login?error=" + encodeURIComponent("Email harus diisi"))
  }

  const { error } = await supabase.auth.resend({
    type: "signup",
    email: email,
    options: {
      emailRedirectTo: `${process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000"}/auth/confirm`,
    },
  })

  if (error) {
    redirect("/login?error=" + encodeURIComponent(error.message))
  }

  redirect("/login?message=" + encodeURIComponent("Email konfirmasi telah dikirim ulang. Cek inbox kamu."))
}
