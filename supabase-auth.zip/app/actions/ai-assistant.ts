"use server"

export async function askTradingQuestion(question: string) {
  try {
    // Simulasi delay untuk efek realistis
    await new Promise((resolve) => setTimeout(resolve, Math.random() * 1500 + 1000))

    const lowerQuestion = question.toLowerCase()

    // Database jawaban yang lebih komprehensif dan profesional
    const responses = {
      support_resistance: [
        `**📊 Support & Resistance: Fondasi Analisis Teknikal**

Support dan Resistance adalah konsep paling fundamental dalam trading. Mari saya jelaskan secara detail:

**🎯 Definisi:**
• **Support**: Level harga dimana tekanan beli cukup kuat untuk menahan penurunan harga
• **Resistance**: Level harga dimana tekanan jual cukup kuat untuk menahan kenaikan harga

**🔍 Cara Mengidentifikasi:**
1. **Historical Price Action**: Cari level yang pernah ditest minimal 2-3 kali
2. **Volume Confirmation**: Perhatikan volume tinggi saat harga mendekati level tersebut
3. **Multiple Timeframe**: Konfirmasi di timeframe yang berbeda (H4, Daily, Weekly)
4. **Round Numbers**: Angka bulat seperti 4000, 5000 sering menjadi psychological level

**💡 Strategi Trading:**
• **Bounce Strategy**: Buy di support, Sell di resistance
• **Breakout Strategy**: Entry saat harga break level dengan volume tinggi
• **Retest Strategy**: Entry saat harga retest level yang sudah broken

**⚠️ Tips Penting:**
- Support yang broken sering menjadi resistance baru (dan sebaliknya)
- Semakin sering level ditest, semakin kuat level tersebut
- Selalu gunakan stop loss 10-20 pips di bawah support (untuk buy)

**📈 Contoh Praktis:**
Jika BBRI pernah bounce dari level 4500 sebanyak 3 kali, maka 4500 adalah strong support. Anda bisa buy di 4520 dengan SL di 4480 dan target di resistance berikutnya.`,

        `**🏗️ Support & Resistance: Membangun Strategi yang Solid**

Mari kita bahas lebih mendalam tentang S&R sebagai pondasi trading yang profitable:

**🎨 Jenis-Jenis Support & Resistance:**

1. **Horizontal S&R**: Level harga yang jelas terlihat di chart
2. **Dynamic S&R**: Moving Average yang berperan sebagai S&R
3. **Diagonal S&R**: Trendline yang berfungsi sebagai S&R
4. **Fibonacci S&R**: Level retracement 38.2%, 50%, 61.8%

**🧠 Psikologi di Balik S&R:**
• **Support**: Area dimana fear of missing out (FOMO) mendorong buying pressure
• **Resistance**: Area dimana profit-taking dan fear mendorong selling pressure
• **Memory Effect**: Trader mengingat level-level penting sebelumnya

**📊 Teknik Analisis Lanjutan:**
1. **Confluence Zone**: Area dimana beberapa S&R bertemu
2. **Volume Profile**: Identifikasi high volume nodes sebagai S&R
3. **Market Structure**: Higher highs/lows untuk trend identification

**🎯 Setup Trading Favorit:**
• **Double Bottom di Support**: Signal bullish yang kuat
• **Triple Top di Resistance**: Signal bearish yang reliable
• **Flag Pattern**: Continuation pattern yang respect S&R

**💰 Money Management:**
- Risk 1-2% per trade
- Risk-Reward ratio minimal 1:2
- Position sizing berdasarkan jarak ke stop loss

Ingat: S&R bukan garis exact, tapi zona. Berikan toleransi 0.1-0.2% untuk noise market.`,
      ],

      risk_management: [
        `**🛡️ Risk Management: Kunci Bertahan di Pasar Modal**

Risk Management adalah skill #1 yang harus dikuasai trader. Tanpa ini, modal Anda akan habis lebih cepat dari yang dibayangkan.

**📏 The 1% Rule - Aturan Emas:**
Jangan pernah risk lebih dari 1% modal per trade. Dengan aturan ini:
• 10 loss berturut-turut = -10% modal
• Masih punya 90% modal untuk recovery
• Psychological pressure lebih rendah

**🧮 Formula Position Sizing:**
Position Size = (Modal × Risk %) ÷ (Entry Price - Stop Loss)

**Contoh Perhitungan:**
• Modal: Rp 100,000,000
• Risk: 1% = Rp 1,000,000
• Entry BBRI: Rp 4,500
• Stop Loss: Rp 4,400 (risk Rp 100 per saham)
• Position Size: Rp 1,000,000 ÷ Rp 100 = 10,000 saham

**🎯 Risk-Reward Ratio:**
• Minimum 1:2 (risk Rp 1 untuk profit Rp 2)
• Sweet spot 1:3 untuk swing trading
• Scalper bisa 1:1 dengan win rate tinggi

**📊 Portfolio Risk Management:**
• Total risk semua open position max 5%
• Diversifikasi across sectors
• Avoid correlation risk (jangan trade saham sejenis)

**🧠 Psychological Aspects:**
• Stick to your plan, jangan emotional
• Accept losses sebagai cost of doing business
• Focus on process, bukan hasil individual trade

**⚡ Advanced Techniques:**
• Kelly Criterion untuk optimal position sizing
• Volatility-based position sizing
• Correlation analysis untuk portfolio risk`,

        `**💰 Money Management: Dari Pemula ke Profesional**

Mari saya bagi tahapan money management berdasarkan level experience:

**🌱 Level Pemula (0-6 bulan):**
• Risk maksimal 0.5% per trade
• Maksimal 2 posisi bersamaan
• Focus di saham blue chip (BBRI, TLKM, UNVR)
• No leverage sampai konsisten profit

**📈 Level Menengah (6-18 bulan):**
• Risk 1% per trade
• Maksimal 5 posisi bersamaan
• Mulai diversifikasi sektor
• Leverage kecil (maksimal 1:2)

**🏆 Level Advanced (18+ bulan):**
• Risk 1-2% per trade
• Portfolio approach dengan 10+ posisi
• Sector rotation strategy
• Leverage dengan proper risk control

**📊 Metrik Performance Penting:**
• **Sharpe Ratio**: (Return - Risk-free rate) ÷ Standard deviation
• **Maximum Drawdown**: Penurunan terbesar dari peak ke trough
• **Win Rate**: Persentase trade yang profit
• **Average Win vs Average Loss**: Harus positif

**🎪 Drawdown Management:**
• Stop trading setelah drawdown 10%
• Reduce position size 50% setelah drawdown 5%
• Take break dan review strategy

**🧘 Mental Framework:**
• Treat trading sebagai bisnis, bukan gambling
• Keep detailed journal untuk setiap trade
• Regular review dan improvement

Ingat: Preservation of capital lebih penting dari making money!`,
      ],

      psychology: [
        `**🧠 Trading Psychology: Menguasai Mind Game**

80% trading adalah mental game. Mari kita bahas bagaimana menguasai aspek psikologi:

**🎭 Siklus Emosi Trader:**
1. **Optimisme** → Entry dengan confidence
2. **Excitement** → Trade mulai profit  
3. **Euphoria** → Merasa invincible, ambil risk berlebihan
4. **Anxiety** → Market berubah, profit berkurang
5. **Fear** → Realize loss is real
6. **Panic** → Cut loss di timing terburuk
7. **Capitulation** → Give up trading
8. **Depression** → Titik terendah
9. **Hope** → "Maybe I can try again"
10. **Relief** → Small wins restore confidence

**🔄 Breaking the Cycle:**
• **Pre-defined Rules**: Entry, exit, risk management yang jelas
• **Trading Journal**: Catat emosi, bukan cuma P&L
• **Meditation**: 10 menit daily untuk mental clarity
• **Physical Exercise**: Reduce stress hormones
• **Proper Sleep**: 7-8 jam untuk optimal decision making

**🪤 Psychological Traps:**
• **Confirmation Bias**: Cuma lihat info yang confirm bias kita
• **Anchoring**: Stuck di entry price atau previous high/low
• **Loss Aversion**: Takut cut loss kecil, malah jadi loss besar
• **Overconfidence**: Setelah beberapa win, ambil risk berlebihan

**💪 Mental Models untuk Sukses:**
• Think in probabilities, not certainties
• Focus on process, not outcomes  
• Embrace uncertainty sebagai bagian dari game
• Treat each trade as independent event

**🎯 Practical Tips:**
• Set daily loss limit dan stick to it
• Take mandatory break setelah 2 loss berturut
• Celebrate small wins, learn from losses
• Build support system dengan fellow traders`,

        `**🎭 Mengatasi Fear & Greed dalam Trading**

Fear dan Greed adalah dua emosi yang paling destructive dalam trading. Mari kita bahas cara mengatasinya:

**😨 Fear of Missing Out (FOMO):**
*Gejala:* Chase breakout, entry terlambat, overtrading
*Solusi:*
• Set alerts instead of staring at charts
• Remember: selalu ada opportunity berikutnya
• Focus pada best setup saja, ignore the rest

**💸 Fear of Losing Money:**
*Gejala:* Tidak ambil trade, exit terlalu cepat, analysis paralysis
*Solusi:*
• Start dengan paper trading
• Use proper position sizing
• Accept losses sebagai business expense

**🤑 Greed:**
*Gejala:* Tidak take profit, add position recklessly, overleveraging
*Solusi:*
• Set profit target sebelum entry
• Use trailing stops
• Take partial profit di key levels

**😡 Revenge Trading:**
*Gejala:* Double down setelah loss, abandon strategy, emotional decisions
*Solusi:*
• Mandatory break setelah 2 consecutive losses
• Review apa yang salah
• Stick to position sizing rules

**🎪 Building Mental Resilience:**
• **Visualization**: Mental rehearsal berbagai scenario
• **Stress Testing**: Practice dengan small amounts dulu
• **Support System**: Connect dengan trader lain
• **Continuous Learning**: Baca trading psychology books

**📚 Recommended Reading:**
• "Trading in the Zone" - Mark Douglas
• "The Psychology of Trading" - Brett Steenbarger  
• "Market Wizards" - Jack Schwager

Remember: Market akan selalu ada, tapi modal tidak akan ada jika tidak diprotect!`,
      ],

      technical_analysis: [
        `**📊 Technical Analysis: Membaca Bahasa Market**

Technical Analysis adalah seni membaca price action dan volume untuk predict future price movement. Mari kita pelajari step by step:

**🕯️ Candlestick Patterns (Single Candle):**
• **Doji**: Indecision, potential reversal di key levels
• **Hammer**: Bullish reversal setelah downtrend
• **Shooting Star**: Bearish reversal setelah uptrend  
• **Marubozu**: Strong continuation signal

**🕯️ Candlestick Patterns (Multiple Candles):**
• **Engulfing**: Strong reversal signal
• **Morning/Evening Star**: Three-candle reversal pattern
• **Inside Bar**: Consolidation, breakout pending
• **Outside Bar**: High volatility, potential trend change

**📈 Chart Patterns:**
• **Triangles**: Symmetrical, ascending, descending
• **Flags & Pennants**: Continuation patterns
• **Head & Shoulders**: Reversal pattern yang reliable
• **Double Top/Bottom**: Reversal di key levels

**📊 Volume Analysis:**
Volume adalah konfirmasi dari price movement:
• High volume + breakout = strong signal
• Low volume + breakout = weak signal  
• Volume divergence = potential reversal

**⏰ Multi-Timeframe Analysis:**
1. **Weekly**: Overall trend direction
2. **Daily**: Entry/exit timing
3. **4H**: Fine-tune entries
4. **1H**: Precise execution

**🎯 Key Levels to Watch:**
• Previous day high/low
• Weekly/monthly pivots
• Round numbers (psychological levels)
• Fibonacci retracements (38.2%, 50%, 61.8%)

**💡 Pro Tips:**
• Price action > indicators
• Context is everything
• Confluence of multiple signals
• Always consider market sentiment`,

        `**🔧 Indikator Teknikal: Tools untuk Decision Making**

Indikator adalah tools bantu, bukan holy grail. Mari kita pelajari cara menggunakannya dengan benar:

**📈 Moving Averages:**
• **SMA**: Simple average, bagus untuk trend identification
• **EMA**: Exponential, lebih responsive ke recent price
• **Popular Combinations**: 20/50 EMA, 8/21 EMA, 200 SMA

**⚡ RSI (Relative Strength Index):**
Beyond overbought/oversold:
• **Divergence**: Price vs RSI direction
• **Failure Swings**: RSI pattern analysis  
• **Trendline Analysis**: Draw trendlines on RSI

**📊 MACD (Moving Average Convergence Divergence):**
• **Signal Line Cross**: Basic buy/sell signals
• **Zero Line Cross**: Momentum confirmation
• **Histogram Analysis**: Momentum strength
• **Divergence**: Early reversal warning

**🎈 Bollinger Bands:**
• **Squeeze**: Low volatility, breakout coming
• **Walk the Bands**: Strong trend continuation
• **Double Bottom**: Reversal di lower band
• **M-Top**: Reversal di upper band

**🎯 Stochastic Oscillator:**
• **%K and %D**: Fast and slow lines
• **Divergence**: Price vs Stochastic
• **Overbought/Oversold**: Above 80/below 20

**📊 Volume Indicators:**
• **OBV**: On-Balance Volume untuk trend confirmation
• **Volume Profile**: Price levels dengan high volume
• **VWAP**: Volume Weighted Average Price

**🍸 Creating Your Indicator Cocktail:**
Jangan pakai terlalu banyak! Recommended combination:
1. **Trend**: Moving Average
2. **Momentum**: RSI atau Stochastic
3. **Volume**: OBV atau Volume Profile  
4. **Volatility**: Bollinger Bands atau ATR

Remember: Indicators lag price. Price action is king!`,
      ],

      strategies: [
        `**🌊 Swing Trading: Menangkap Pergerakan Besar**

Swing trading adalah strategi menahan posisi 3-10 hari untuk menangkap pergerakan harga yang signifikan.

**⏰ Timeframe & Target:**
• **Analysis**: Daily charts
• **Entry**: 4H charts  
• **Holding Period**: 3-10 hari
• **Target**: 5-15% per trade

**✅ Setup Requirements:**
1. **Trend Identification**: Price above/below 50 EMA
2. **Pullback**: 38.2% - 61.8% Fibonacci retracement
3. **Confluence**: S/R + Fibonacci + MA
4. **Volume**: Increasing pada breakout/reversal

**🎯 Entry Criteria:**
• Bullish divergence pada RSI
• Hammer/doji di support level
• Volume spike pada reversal candle
• Break above previous swing high

**🛡️ Risk Management:**
• SL: Below swing low (bullish setup)
• Target 1: Previous swing high
• Target 2: 1.618 Fibonacci extension
• Trail stop menggunakan 20 EMA

**📊 Best Markets:**
• Trending stocks/forex pairs
• Avoid during earnings/major news
• Works best di trending markets

**💼 Position Sizing:**
Risk 1-2% per trade. Jika SL 5% away, position size = 20-40% portfolio

**📅 Weekly Routine:**
• **Minggu**: Scan untuk setup
• **Senin**: Place orders
• **Rabu**: Review open positions  
• **Jumat**: Close weekly analysis

**💡 Pro Tips:**
• Patience is key - wait for perfect setup
• Don't force trades di sideways market
• Keep detailed journal untuk improvement`,

        `**⚡ Scalping: Profit Cepat dengan Risk Terkontrol**

Scalping adalah strategi high-frequency trading untuk profit kecil tapi konsisten.

**⏰ Timeframe & Target:**
• **Charts**: 1-5 menit
• **Holding**: Detik sampai menit
• **Target**: 0.1-0.5% per trade

**🏛️ Market Requirements:**
• High liquidity (major forex pairs, large cap stocks)
• Tight spreads
• High volatility periods (London/NY overlap)

**🎯 Setup: The 5-Minute Scalp:**
1. **Trend**: 20 EMA above/below 50 EMA
2. **Entry**: Price pullback ke 20 EMA
3. **Confirmation**: Stochastic oversold/overbought
4. **Volume**: Above average

**📋 Entry Rules:**
• Wait price touch 20 EMA
• Stochastic harus di extreme zone
• Enter pada next candle close in trend direction
• Volume harus above 20-period average

**🚪 Exit Rules:**
• Target: 2-3 times the spread
• SL: 5-10 pips (forex) atau 0.2% (stocks)
• Time stop: Exit jika no movement dalam 5 menit

**🛡️ Risk Management:**
• Never risk more than 0.5% per trade
• Max 3 consecutive losses then stop
• Daily loss limit: 2% of account

**🕐 Optimal Trading Hours:**
• **London Open**: 08:00-10:00 GMT
• **NY Open**: 13:30-15:30 GMT
• **Overlap**: 13:30-16:00 GMT (best)

**🧠 Psychology untuk Scalping:**
• Mechanical execution
• No emotional attachment
• Quick decision making
• Accept small losses quickly

**⚠️ Warning:** Scalping requires intense focus dan tidak cocok untuk part-time traders!`,

        `**🚀 Breakout Trading: Riding the Momentum**

Breakout trading adalah strategi menangkap initial thrust saat price break key levels.

**🎪 Types of Breakouts:**
1. **Range Breakout**: Price break horizontal S/R
2. **Triangle Breakout**: Price break triangle pattern
3. **Trendline Breakout**: Price break major trendline
4. **Moving Average Breakout**: Price break key MA

**✅ High-Probability Breakout Criteria:**
• **Consolidation**: Minimal 20 periods sideways movement
• **Volume**: 50% above average pada breakout
• **Follow-through**: Second candle confirms direction
• **No immediate resistance**: Clear path untuk continuation

**🎯 Perfect Breakout Setup:**
1. **Identify**: Strong S/R level tested multiple times
2. **Wait**: Untuk consolidation near the level
3. **Volume**: Watch untuk volume buildup
4. **Entry**: Break + close above/below level
5. **Confirmation**: Next candle continues same direction

**📊 Entry Techniques:**
• **Aggressive**: Enter pada break of level
• **Conservative**: Wait untuk retest of broken level
• **Momentum**: Enter pada second confirmation candle

**🛡️ Risk Management:**
• SL: Back inside the range/pattern
• Target 1: Height of range added to breakout point
• Target 2: Next major S/R level
• Trail: Use ATR-based trailing stop

**🚫 False Breakout Protection:**
• Wait untuk candle close beyond level
• Require volume confirmation
• Avoid breakouts near major news
• Use smaller position size initially

**📈 Best Timeframes:**
• Daily charts: Most reliable
• 4H charts: Good balance
• 1H charts: More opportunities, more noise

Remember: Not all breakouts are created equal. Quality over quantity!`,
      ],

      fundamental_analysis: [
        `**📈 Fundamental Analysis: Memahami Nilai Intrinsik Saham**

Fundamental analysis adalah metode evaluasi saham berdasarkan kondisi keuangan dan bisnis perusahaan.

**📊 Key Financial Ratios:**

**1. Profitability Ratios:**
• **ROE (Return on Equity)**: Net Income ÷ Shareholders' Equity
• **ROA (Return on Assets)**: Net Income ÷ Total Assets  
• **Net Profit Margin**: Net Income ÷ Revenue
• **Gross Profit Margin**: Gross Profit ÷ Revenue

**2. Valuation Ratios:**
• **P/E Ratio**: Price per Share ÷ Earnings per Share
• **P/B Ratio**: Price per Share ÷ Book Value per Share
• **PEG Ratio**: P/E Ratio ÷ Growth Rate
• **P/S Ratio**: Market Cap ÷ Revenue

**3. Liquidity Ratios:**
• **Current Ratio**: Current Assets ÷ Current Liabilities
• **Quick Ratio**: (Current Assets - Inventory) ÷ Current Liabilities
• **Cash Ratio**: Cash ÷ Current Liabilities

**4. Leverage Ratios:**
• **Debt-to-Equity**: Total Debt ÷ Total Equity
• **Interest Coverage**: EBIT ÷ Interest Expense

**🔍 Analisis Laporan Keuangan:**
• **Income Statement**: Revenue, expenses, profit trends
• **Balance Sheet**: Assets, liabilities, equity composition
• **Cash Flow Statement**: Operating, investing, financing activities

**🏭 Industry Analysis:**
• Market size dan growth potential
• Competitive landscape
• Regulatory environment
• Cyclical vs defensive sectors

**💡 Red Flags to Avoid:**
• Declining revenue untuk 3+ quarters
• Debt-to-equity ratio > 2
• Negative cash flow from operations
• Frequent management changes

**📅 Economic Indicators:**
• GDP growth rate
• Inflation rate
• Interest rates
• Currency strength

Combine fundamental dengan technical analysis untuk hasil optimal!`,
      ],

      market_analysis: [
        `**🌍 Analisis Pasar: Memahami Kondisi Market Saat Ini**

Market analysis adalah kunci untuk memahami kondisi pasar dan mengambil keputusan trading yang tepat.

**📊 Market Phases:**

**1. Bull Market:**
• Karakteristik: Rising prices, high volume, positive sentiment
• Strategy: Buy the dips, hold winners, momentum trading
• Duration: Biasanya 2-5 tahun

**2. Bear Market:**
• Karakteristik: Falling prices, high volatility, negative sentiment  
• Strategy: Short selling, defensive stocks, cash position
• Duration: Biasanya 6 bulan - 2 tahun

**3. Sideways Market:**
• Karakteristik: Range-bound, low volatility
• Strategy: Range trading, sell high buy low
• Duration: Bervariasi

**📈 Market Sentiment Indicators:**
• **VIX (Fear Index)**: Above 30 = fear, below 20 = complacency
• **Put/Call Ratio**: Above 1.0 = bearish, below 0.8 = bullish
• **Margin Debt**: High margin = potential reversal
• **Insider Trading**: Insider buying = bullish signal

**🏛️ Sektor Rotation:**
• **Early Bull**: Technology, Consumer Discretionary
• **Mid Bull**: Industrials, Materials
• **Late Bull**: Energy, Financials
• **Bear Market**: Utilities, Consumer Staples, Healthcare

**📅 Seasonal Patterns:**
• **January Effect**: Small caps outperform
• **Sell in May**: Summer months historically weak
• **Santa Claus Rally**: December often positive
• **Election Year**: Volatility around elections

**🌐 Global Factors:**
• Central bank policies
• Geopolitical events
• Trade wars/agreements
• Currency movements

**💡 Practical Application:**
• Adjust position sizing based on market phase
• Sector rotation untuk portfolio optimization
• Use sentiment indicators untuk contrarian signals
• Monitor global events untuk risk management

Stay informed, stay flexible, stay profitable!`,
      ],
    }

    // Fungsi untuk memilih jawaban secara random dari array
    function getRandomResponse(responseArray: string[]): string {
      return responseArray[Math.floor(Math.random() * responseArray.length)]
    }

    // Pattern matching yang lebih sophisticated dengan bahasa Indonesia
    let answer = ""

    if (
      lowerQuestion.includes("support") ||
      lowerQuestion.includes("resistance") ||
      lowerQuestion.includes("sr") ||
      lowerQuestion.includes("level") ||
      lowerQuestion.includes("zona")
    ) {
      answer = getRandomResponse(responses.support_resistance)
    } else if (
      lowerQuestion.includes("risk") ||
      lowerQuestion.includes("risiko") ||
      lowerQuestion.includes("money management") ||
      lowerQuestion.includes("manajemen") ||
      lowerQuestion.includes("position sizing") ||
      lowerQuestion.includes("modal")
    ) {
      answer = getRandomResponse(responses.risk_management)
    } else if (
      lowerQuestion.includes("loss") ||
      lowerQuestion.includes("rugi") ||
      lowerQuestion.includes("psikologi") ||
      lowerQuestion.includes("psychology") ||
      lowerQuestion.includes("emosi") ||
      lowerQuestion.includes("mental") ||
      lowerQuestion.includes("takut") ||
      lowerQuestion.includes("greed") ||
      lowerQuestion.includes("serakah")
    ) {
      answer = getRandomResponse(responses.psychology)
    } else if (
      lowerQuestion.includes("teknikal") ||
      lowerQuestion.includes("technical") ||
      lowerQuestion.includes("indikator") ||
      lowerQuestion.includes("indicator") ||
      lowerQuestion.includes("chart") ||
      lowerQuestion.includes("candlestick") ||
      lowerQuestion.includes("rsi") ||
      lowerQuestion.includes("macd") ||
      lowerQuestion.includes("moving average")
    ) {
      answer = getRandomResponse(responses.technical_analysis)
    } else if (
      lowerQuestion.includes("strategi") ||
      lowerQuestion.includes("strategy") ||
      lowerQuestion.includes("scalping") ||
      lowerQuestion.includes("swing") ||
      lowerQuestion.includes("breakout") ||
      lowerQuestion.includes("trading plan")
    ) {
      answer = getRandomResponse(responses.strategies)
    } else if (
      lowerQuestion.includes("fundamental") ||
      lowerQuestion.includes("laporan keuangan") ||
      lowerQuestion.includes("financial") ||
      lowerQuestion.includes("pe ratio") ||
      lowerQuestion.includes("roe") ||
      lowerQuestion.includes("valuasi")
    ) {
      answer = getRandomResponse(responses.fundamental_analysis)
    } else if (
      lowerQuestion.includes("market") ||
      lowerQuestion.includes("pasar") ||
      lowerQuestion.includes("sentiment") ||
      lowerQuestion.includes("bull") ||
      lowerQuestion.includes("bear") ||
      lowerQuestion.includes("analisis pasar")
    ) {
      answer = getRandomResponse(responses.market_analysis)
    } else {
      // Jawaban dinamis untuk pertanyaan umum dengan bahasa Indonesia yang baik
      const generalResponses = [
        `**🤔 Pertanyaan yang Menarik!**

Terima kasih atas pertanyaannya. Berdasarkan pengalaman saya menganalisis ribuan kasus trading, hal ini memang tergantung pada beberapa faktor penting:

**📊 Faktor-faktor yang Perlu Dipertimbangkan:**
• **Kondisi Market**: Apakah sedang trending, sideways, atau volatile?
• **Timeframe Trading**: Scalping, day trading, atau swing trading?
• **Risk Tolerance**: Seberapa besar risiko yang bisa Anda terima?
• **Experience Level**: Pemula, menengah, atau advanced trader?
• **Capital Size**: Ukuran modal yang tersedia untuk trading

**💡 Saran Saya:**
Untuk memberikan jawaban yang lebih spesifik dan actionable, bisa tolong berikan detail lebih lanjut tentang:
- Timeframe yang biasa Anda gunakan?
- Instrumen trading favorit (saham, forex, crypto)?
- Level pengalaman trading Anda?
- Tantangan spesifik yang sedang dihadapi?

**🎯 Prinsip Universal:**
Apapun situasinya, selalu ingat:
1. **Risk Management First** - Lindungi modal sebelum kejar profit
2. **Consistency Over Big Wins** - Small consistent gains lebih baik
3. **Patience & Discipline** - Tunggu setup yang high-probability
4. **Continuous Learning** - Market selalu berubah, kita harus adaptasi

Silakan berikan detail lebih spesifik, saya akan berikan panduan yang lebih tepat sasaran! 🚀`,

        `**💡 Insight Trading yang Berharga!**

Pertanyaan Anda menyentuh aspek penting dalam trading. Mari saya berikan perspektif berdasarkan analisis mendalam:

**🎯 Konteks adalah Segalanya**
Dalam trading, tidak ada jawaban yang "one size fits all". Setiap situasi membutuhkan pendekatan yang berbeda berdasarkan:

**📈 Kondisi Market Saat Ini:**
• **Trending Market**: Momentum strategy lebih efektif
• **Sideways Market**: Range trading dan mean reversion
• **Volatile Market**: Risk management ekstra ketat
• **Low Volatility**: Breakout strategy preparation

**🧠 Faktor Psikologi:**
• **Confidence Level**: Berpengaruh pada execution
• **Risk Appetite**: Menentukan position sizing
• **Time Availability**: Full-time vs part-time trader
• **Stress Tolerance**: Mempengaruhi holding period

**⚡ Actionable Steps:**
1. **Assess Current Situation**: Evaluasi kondisi market dan personal
2. **Define Clear Objectives**: Apa yang ingin dicapai?
3. **Create Action Plan**: Step-by-step implementation
4. **Monitor & Adjust**: Regular review dan improvement

**🔍 Pertanyaan Reflektif:**
- Apa goal utama Anda dalam trading?
- Challenge terbesar yang sedang dihadapi?
- Resource apa yang tersedia (waktu, modal, tools)?

Berikan detail lebih spesifik tentang situasi Anda, saya akan berikan solusi yang lebih targeted dan praktis! 💪`,

        `**🎓 Mari Kita Analisis Lebih Dalam!**

Pertanyaan yang sangat bagus! Ini menunjukkan Anda sedang berpikir seperti trader profesional yang mempertimbangkan berbagai aspek.

**🔬 Pendekatan Analitis:**
Berdasarkan pengalaman menganalisis ribuan case study trading, ada beberapa framework yang bisa kita gunakan:

**1. Market Context Analysis:**
• **Macro Environment**: Kondisi ekonomi global dan domestik
• **Sector Performance**: Sektor mana yang sedang outperform
• **Individual Stock**: Fundamental dan technical condition
• **Sentiment Analysis**: Fear vs greed index

**2. Personal Trading Framework:**
• **Risk Profile**: Conservative, moderate, atau aggressive
• **Time Horizon**: Short-term vs long-term perspective  
• **Skill Level**: Technical analysis, fundamental, atau hybrid
• **Capital Allocation**: Berapa persen portfolio untuk trading

**3. Execution Strategy:**
• **Entry Criteria**: Kondisi apa yang harus terpenuhi
• **Exit Strategy**: Profit target dan stop loss
• **Position Management**: Scaling in/out, trailing stops
• **Review Process**: Regular evaluation dan improvement

**💭 Pertanyaan Kunci untuk Anda:**
- Apa style trading yang paling cocok dengan personality Anda?
- Berapa waktu yang bisa dialokasikan untuk trading daily?
- Apa instrumen trading yang paling Anda pahami?

**🚀 Next Steps:**
Ceritakan lebih detail tentang:
1. Situasi trading current Anda
2. Goals yang ingin dicapai
3. Challenges yang sedang dihadapi

Dengan informasi ini, saya bisa memberikan roadmap yang lebih spesifik dan actionable! 🎯`,
      ]

      answer = getRandomResponse(generalResponses)
    }

    return { success: true, answer }
  } catch (error) {
    console.error("AI Assistant error:", error)
    return {
      success: false,
      error: "Maaf, terjadi kesalahan sistem. Silakan coba lagi dalam beberapa saat.",
    }
  }
}
