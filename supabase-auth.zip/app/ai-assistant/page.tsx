import { createClient } from "@/utils/supabase/server"
import { cookies } from "next/headers"
import { redirect } from "next/navigation"
import { Button } from "@/components/ui/button"
import { AIAssistant } from "@/components/ai-assistant"
import { signout } from "@/app/actions/auth"
import Link from "next/link"
import { ArrowLeft, Brain, TrendingUp } from "lucide-react"

export default async function AIAssistantPage() {
  const supabase = await createClient(cookies)
  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) redirect("/login")

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-blue-100">
      {/* Header */}
      <header className="bg-white shadow-lg border-b-4 border-blue-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-6">
            <div className="flex items-center gap-6">
              <Button
                variant="ghost"
                size="sm"
                asChild
                className="text-blue-600 hover:bg-blue-50 hover:text-blue-700 font-medium"
              >
                <Link href="/dashboard">
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Kembali ke Dashboard
                </Link>
              </Button>

              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-blue-600 rounded-full flex items-center justify-center">
                  <Brain className="w-7 h-7 text-white" />
                </div>
                <div>
                  <h1 className="text-3xl font-bold text-gray-800">AI Trading Expert</h1>
                  <p className="text-blue-600 font-medium">Konsultasi Trading Profesional</p>
                </div>
              </div>

              <form action={signout}>
                <Button
                  variant="outline"
                  className="border-2 border-blue-300 text-blue-600 hover:bg-blue-50 hover:border-blue-400 h-12 px-6"
                >
                  Keluar
                </Button>
              </form>
            </div>

            <div className="flex items-center">{/* Empty space for balance */}</div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8 text-center">
          <div className="flex items-center justify-center gap-3 mb-4">
            <TrendingUp className="w-8 h-8 text-blue-600" />
            <h2 className="text-2xl font-bold text-gray-800">Konsultasi dengan AI Trading Expert</h2>
          </div>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Dapatkan insight mendalam tentang strategi trading, analisis teknikal, risk management, dan tips profesional
            dari AI yang telah dilatih dengan ribuan kasus trading sukses.
          </p>
        </div>

        <AIAssistant />
      </main>

      {/* Footer */}
      <footer className="bg-white border-t-4 border-blue-500 mt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="text-center">
            <p className="text-lg font-bold text-gray-800 mb-1">#kyotrader all rights reserved</p>
            <p className="text-blue-600 font-medium">AI Trading Assistant • Professional Trading Intelligence</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
