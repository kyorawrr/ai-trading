import { login, signup, resendConfirmation } from "@/app/actions/auth"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Separator } from "@/components/ui/separator"
import { TrendingUp, Mail, Lock } from "lucide-react"

export default function LoginPage({
  searchParams,
}: {
  searchParams: { error?: string; message?: string }
}) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-blue-100 flex flex-col">
      <div className="flex-1 flex items-center justify-center p-4">
        <Card className="w-full max-w-md bg-white shadow-2xl border-2 border-blue-200">
          <CardHeader className="bg-gradient-to-r from-blue-500 to-blue-600 text-white rounded-t-lg">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center">
                <TrendingUp className="w-7 h-7 text-white" />
              </div>
              <div>
                <CardTitle className="text-2xl font-bold">AI Trading Assistant</CardTitle>
                <CardDescription className="text-blue-100 text-base">Professional Trading Intelligence</CardDescription>
              </div>
            </div>
          </CardHeader>

          {searchParams.error && (
            <div className="px-6 pt-4">
              <Alert variant="destructive" className="border-2 border-red-300 bg-red-50">
                <AlertDescription className="text-red-800 font-medium">
                  {decodeURIComponent(searchParams.error)}
                </AlertDescription>
              </Alert>
            </div>
          )}

          {searchParams.message && (
            <div className="px-6 pt-4">
              <Alert className="border-2 border-blue-300 bg-blue-50">
                <AlertDescription className="text-blue-800 font-medium">
                  {decodeURIComponent(searchParams.message)}
                </AlertDescription>
              </Alert>
            </div>
          )}

          <form>
            <CardContent className="space-y-6 p-8">
              <div className="space-y-3">
                <Label htmlFor="email" className="text-gray-800 font-semibold text-base">
                  Alamat Email
                </Label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-500" />
                  <Input
                    id="email"
                    name="email"
                    type="email"
                    required
                    placeholder="nama@email.com"
                    autoComplete="email"
                    className="h-12 pl-10 border-2 border-blue-200 focus:border-blue-400 focus:ring-blue-400 text-gray-800 text-base placeholder:text-gray-500"
                  />
                </div>
              </div>

              <div className="space-y-3">
                <Label htmlFor="password" className="text-gray-800 font-semibold text-base">
                  Password
                </Label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-500" />
                  <Input
                    id="password"
                    name="password"
                    type="password"
                    required
                    placeholder="Minimal 6 karakter"
                    minLength={6}
                    autoComplete="current-password"
                    className="h-12 pl-10 border-2 border-blue-200 focus:border-blue-400 focus:ring-blue-400 text-gray-800 text-base placeholder:text-gray-500"
                  />
                </div>
              </div>
            </CardContent>

            <CardFooter className="flex flex-col gap-4 px-8 pb-8">
              <div className="flex gap-3 w-full">
                <Button
                  formAction={login}
                  className="flex-1 h-12 bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white text-base font-semibold shadow-lg hover:shadow-xl transition-all duration-300"
                >
                  Masuk
                </Button>
                <Button
                  formAction={signup}
                  variant="outline"
                  className="flex-1 h-12 border-2 border-blue-300 text-blue-600 hover:bg-blue-50 hover:border-blue-400 text-base font-semibold"
                >
                  Daftar
                </Button>
              </div>

              <Separator className="bg-blue-200" />

              <div className="w-full text-center">
                <p className="text-sm text-gray-600 mb-3 font-medium">Belum menerima email konfirmasi?</p>
                <Button
                  formAction={resendConfirmation}
                  variant="ghost"
                  size="sm"
                  className="text-blue-600 hover:bg-blue-50 hover:text-blue-700 font-medium"
                >
                  Kirim Ulang Email Konfirmasi
                </Button>
              </div>
            </CardFooter>
          </form>
        </Card>
      </div>

      {/* Footer */}
      <footer className="bg-white border-t-4 border-blue-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="text-center">
            <p className="text-lg font-bold text-gray-800 mb-1">#kyotrader all rights reserved</p>
            <p className="text-blue-600 font-medium">AI Trading Assistant • Professional Trading Intelligence</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
