import { createClient } from "@/utils/supabase/server"
import { cookies } from "next/headers"
import { redirect } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { TradingForm } from "@/components/trading-form"
import { TradingRecords } from "@/components/trading-records"
import { signout } from "@/app/actions/auth"
import { getTradingSummary } from "@/app/actions/trading"
import { TrendingUp, TrendingDown, Activity, Target, Bot } from "lucide-react"
import Link from "next/link"

export default async function DashboardPage({
  searchParams,
}: {
  searchParams: { error?: string; success?: string; message?: string }
}) {
  const supabase = await createClient(cookies)
  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) redirect("/login")

  const { summary } = await getTradingSummary()

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-blue-100">
      {/* Header */}
      <header className="bg-white shadow-lg border-b-4 border-blue-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-6">
            <div className="flex items-center gap-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-blue-600 rounded-full flex items-center justify-center">
                  <TrendingUp className="w-7 h-7 text-white" />
                </div>
                <div>
                  <h1 className="text-3xl font-bold text-gray-800">AI Trading Assistant</h1>
                  <p className="text-blue-600 font-medium">Selamat datang, {user.email?.split("@")[0]} 👋</p>
                </div>
              </div>

              <div className="flex items-center gap-4">
                <Button
                  asChild
                  className="bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white shadow-lg hover:shadow-xl transition-all duration-300 h-12 px-6"
                >
                  <Link href="/ai-assistant">
                    <Bot className="w-5 h-5 mr-2" />
                    Tanya AI Expert
                  </Link>
                </Button>

                <form action={signout}>
                  <Button
                    variant="outline"
                    className="border-2 border-blue-300 text-blue-600 hover:bg-blue-50 hover:border-blue-400 h-12 px-6"
                  >
                    Keluar
                  </Button>
                </form>
              </div>
            </div>

            <div className="flex items-center">{/* Empty space for balance */}</div>
          </div>
        </div>
      </header>

      {/* Alerts */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-6">
        {searchParams.error && (
          <Alert variant="destructive" className="mb-4 border-2 border-red-300 bg-red-50">
            <AlertDescription className="text-red-800 font-medium">
              {decodeURIComponent(searchParams.error)}
            </AlertDescription>
          </Alert>
        )}

        {searchParams.success && (
          <Alert className="mb-4 border-2 border-green-300 bg-green-50">
            <AlertDescription className="text-green-800 font-medium">
              {decodeURIComponent(searchParams.success)}
            </AlertDescription>
          </Alert>
        )}

        {searchParams.message && (
          <Alert className="mb-4 border-2 border-blue-300 bg-blue-50">
            <AlertDescription className="text-blue-800 font-medium">
              {decodeURIComponent(searchParams.message)}
            </AlertDescription>
          </Alert>
        )}
      </div>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Summary Cards */}
        {summary && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <Card className="bg-white border-2 border-blue-200 shadow-lg hover:shadow-xl transition-all duration-300">
              <CardHeader className="pb-3 border-b border-blue-100">
                <CardTitle className="text-base font-semibold text-gray-700 flex items-center gap-2">
                  <Target className="w-5 h-5 text-blue-500" />
                  Net Profit/Loss
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-4">
                <div className={`text-3xl font-bold ${summary.netProfitLoss >= 0 ? "text-green-600" : "text-red-600"}`}>
                  {summary.netProfitLoss >= 0 ? "+" : ""}Rp {summary.netProfitLoss.toLocaleString("id-ID")}
                </div>
                <p className="text-sm text-gray-500 mt-1">Total Performance</p>
              </CardContent>
            </Card>

            <Card className="bg-white border-2 border-green-200 shadow-lg hover:shadow-xl transition-all duration-300">
              <CardHeader className="pb-3 border-b border-green-100">
                <CardTitle className="text-base font-semibold text-gray-700 flex items-center gap-2">
                  <TrendingUp className="w-5 h-5 text-green-500" />
                  Total Profit
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-4">
                <div className="text-3xl font-bold text-green-600">
                  +Rp {summary.totalProfit.toLocaleString("id-ID")}
                </div>
                <p className="text-sm text-gray-500 mt-1">{summary.winningTrades} winning trades</p>
              </CardContent>
            </Card>

            <Card className="bg-white border-2 border-red-200 shadow-lg hover:shadow-xl transition-all duration-300">
              <CardHeader className="pb-3 border-b border-red-100">
                <CardTitle className="text-base font-semibold text-gray-700 flex items-center gap-2">
                  <TrendingDown className="w-5 h-5 text-red-500" />
                  Total Loss
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-4">
                <div className="text-3xl font-bold text-red-600">
                  Rp {Math.abs(summary.totalLoss).toLocaleString("id-ID")}
                </div>
                <p className="text-sm text-gray-500 mt-1">{summary.losingTrades} losing trades</p>
              </CardContent>
            </Card>

            <Card className="bg-white border-2 border-blue-200 shadow-lg hover:shadow-xl transition-all duration-300">
              <CardHeader className="pb-3 border-b border-blue-100">
                <CardTitle className="text-base font-semibold text-gray-700 flex items-center gap-2">
                  <Activity className="w-5 h-5 text-blue-500" />
                  Trading Stats
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-4">
                <div className="text-3xl font-bold text-blue-600">{summary.totalTrades}</div>
                <p className="text-sm text-gray-500 mt-1">
                  Win Rate: <span className="font-semibold text-blue-600">{summary.winRate}%</span>
                </p>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Trading Form and Records */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          <TradingForm />
          <TradingRecords />
        </div>

        {/* AI Assistant Promo */}
        <Card className="bg-gradient-to-r from-blue-500 to-blue-600 text-white border-none shadow-xl">
          <CardContent className="p-8">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-2xl font-bold mb-3">Butuh Bantuan Trading?</h3>
                <p className="mb-6 text-blue-100 text-lg leading-relaxed">
                  Konsultasi dengan AI Expert untuk strategi trading, analisa teknikal, dan tips manajemen risiko yang
                  tepat untuk meningkatkan performa trading Anda.
                </p>
                <Button
                  asChild
                  variant="secondary"
                  className="bg-white text-blue-600 hover:bg-blue-50 shadow-lg hover:shadow-xl transition-all duration-300 h-12 px-8 text-lg font-semibold"
                >
                  <Link href="/ai-assistant">
                    <Bot className="w-5 h-5 mr-2" />
                    Konsultasi AI Expert
                  </Link>
                </Button>
              </div>
              <div className="hidden md:block">
                <Bot className="w-32 h-32 text-white opacity-20" />
              </div>
            </div>
          </CardContent>
        </Card>
      </main>

      {/* Footer */}
      <footer className="bg-white border-t-4 border-blue-500 mt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="text-center">
            <p className="text-lg font-bold text-gray-800 mb-1">#kyotrader all rights reserved</p>
            <p className="text-blue-600 font-medium">AI Trading Assistant • Professional Trading Intelligence</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
