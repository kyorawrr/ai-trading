"use client"

import type React from "react"
import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Card } from "@/components/ui/card"
import { askTradingQuestion } from "@/app/actions/ai-assistant"
import { Bot, User, Send, Loader2, MessageCircle, Lightbulb, TrendingUp, Brain } from "lucide-react"

interface Message {
  id: string
  type: "user" | "assistant"
  content: string
  timestamp: Date
}

const SAMPLE_QUESTIONS = [
  "Bagaimana cara mengidentifikasi support dan resistance yang kuat?",
  "Strategi risk management yang efektif untuk pemula?",
  "Cara mengatasi emosi takut dan serakah saat trading?",
  "Indikator teknikal terbaik untuk swing trading?",
  "Tips scalping yang aman dan profitable?",
  "Cara membaca volume untuk konfirmasi breakout?",
  "Kapan waktu terbaik untuk cut loss?",
  "Strategi diversifikasi portfolio yang optimal?",
]

export function AIAssistant() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "welcome",
      type: "assistant",
      content: `**🎯 Selamat Datang di AI Trading Expert Indonesia!**

Halo! Saya adalah AI Trading Assistant yang dirancang khusus untuk membantu trader Indonesia meningkatkan performa trading mereka.

**🧠 Keahlian Saya:**
• **Analisis Teknikal Mendalam** - Chart patterns, indikator, price action
• **Risk Management Profesional** - Position sizing, portfolio management
• **Trading Psychology** - Mengatasi emosi, membangun disiplin
• **Strategi Trading** - Scalping, swing trading, breakout strategy
• **Analisis Fundamental** - Evaluasi saham berdasarkan laporan keuangan
• **Market Analysis** - Kondisi pasar, sentiment, sektor rotation

**💡 Cara Menggunakan:**
Tanyakan apa saja tentang trading - dari pertanyaan dasar hingga strategi advanced. Saya akan memberikan jawaban yang detail, praktis, dan mudah dipahami.

**🚀 Siap membantu Anda menjadi trader yang lebih baik!**

Silakan pilih pertanyaan di bawah atau ketik pertanyaan Anda sendiri.`,
      timestamp: new Date(),
    },
  ])
  const [input, setInput] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [messages])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!input.trim() || isLoading) return

    const userMessage: Message = {
      id: Date.now().toString(),
      type: "user",
      content: input.trim(),
      timestamp: new Date(),
    }

    setMessages((prev) => [...prev, userMessage])
    setInput("")
    setIsLoading(true)

    try {
      const result = await askTradingQuestion(input.trim())

      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        type: "assistant",
        content: result.success ? result.answer! : result.error!,
        timestamp: new Date(),
      }

      setMessages((prev) => [...prev, assistantMessage])
    } catch (error) {
      const errorMessage: Message = {
        id: (Date.now() + 1).toString(),
        type: "assistant",
        content: "Maaf, terjadi kesalahan sistem. Silakan coba lagi dalam beberapa saat.",
        timestamp: new Date(),
      }
      setMessages((prev) => [...prev, errorMessage])
    } finally {
      setIsLoading(false)
    }
  }

  const handleSampleQuestion = (question: string) => {
    setInput(question)
  }

  return (
    <div className="w-full max-w-6xl mx-auto">
      <Card className="h-[800px] flex flex-col bg-white shadow-2xl border-2 border-blue-200">
        {/* Header */}
        <div className="bg-gradient-to-r from-blue-600 to-blue-700 text-white p-8 rounded-t-lg">
          <div className="flex items-center gap-4 mb-6">
            <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center">
              <Brain className="w-9 h-9 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-bold mb-2">AI Trading Expert Indonesia</h1>
              <p className="text-blue-100 text-lg">
                Assistant Cerdas untuk Trading Profesional • Analisis Mendalam • Strategi Teruji
              </p>
            </div>
          </div>

          {/* Sample Questions */}
          <div className="space-y-4">
            <div className="flex items-center gap-3 text-blue-100">
              <Lightbulb className="w-5 h-5" />
              <span className="font-semibold text-base">Pertanyaan Populer - Klik untuk bertanya:</span>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {SAMPLE_QUESTIONS.map((question, index) => (
                <Button
                  key={index}
                  variant="outline"
                  size="sm"
                  onClick={() => handleSampleQuestion(question)}
                  className="text-left justify-start h-auto p-3 bg-white/10 border-white/20 text-white hover:bg-white/20 hover:border-white/30 transition-all duration-300 text-sm"
                  disabled={isLoading}
                >
                  <MessageCircle className="w-4 h-4 mr-2 flex-shrink-0" />
                  <span className="truncate">{question}</span>
                </Button>
              ))}
            </div>
          </div>
        </div>

        {/* Messages Area */}
        <div className="flex-1 bg-gradient-to-b from-blue-50 to-white overflow-hidden">
          <ScrollArea className="h-full p-6">
            <div className="space-y-8">
              {messages.map((message) => (
                <div
                  key={message.id}
                  className={`flex gap-4 ${message.type === "user" ? "justify-end" : "justify-start"}`}
                >
                  <div
                    className={`flex gap-4 max-w-[90%] ${message.type === "user" ? "flex-row-reverse" : "flex-row"}`}
                  >
                    <div
                      className={`w-12 h-12 rounded-full flex items-center justify-center flex-shrink-0 shadow-lg ${
                        message.type === "user"
                          ? "bg-gradient-to-r from-blue-500 to-blue-600"
                          : "bg-gradient-to-r from-green-500 to-green-600"
                      }`}
                    >
                      {message.type === "user" ? (
                        <User className="w-6 h-6 text-white" />
                      ) : (
                        <Bot className="w-6 h-6 text-white" />
                      )}
                    </div>

                    <div
                      className={`rounded-2xl p-6 shadow-lg ${
                        message.type === "user"
                          ? "bg-gradient-to-r from-blue-500 to-blue-600 text-white"
                          : "bg-white border-2 border-blue-100 text-gray-800"
                      }`}
                    >
                      <div className="prose prose-sm max-w-none">
                        <div
                          className={`text-base leading-relaxed whitespace-pre-wrap font-medium ${
                            message.type === "user" ? "text-white" : "text-gray-800"
                          }`}
                        >
                          {message.content}
                        </div>
                      </div>

                      <div
                        className={`flex items-center gap-2 mt-4 pt-3 border-t ${
                          message.type === "user" ? "border-blue-400/30 text-blue-100" : "border-blue-100 text-gray-500"
                        }`}
                      >
                        <TrendingUp className="w-4 h-4" />
                        <span className="text-sm font-medium">
                          {message.timestamp.toLocaleTimeString("id-ID", {
                            hour: "2-digit",
                            minute: "2-digit",
                          })}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}

              {isLoading && (
                <div className="flex gap-4 justify-start">
                  <div className="flex gap-4 max-w-[90%]">
                    <div className="w-12 h-12 rounded-full flex items-center justify-center flex-shrink-0 bg-gradient-to-r from-green-500 to-green-600 shadow-lg">
                      <Bot className="w-6 h-6 text-white" />
                    </div>
                    <div className="rounded-2xl p-6 bg-white border-2 border-blue-100 shadow-lg">
                      <div className="flex items-center gap-4">
                        <Loader2 className="w-6 h-6 animate-spin text-blue-600" />
                        <span className="text-base text-blue-800 font-medium">
                          Sedang menganalisis pertanyaan Anda...
                        </span>
                        <div className="flex gap-1">
                          <div className="w-2 h-2 bg-blue-400 rounded-full animate-bounce"></div>
                          <div
                            className="w-2 h-2 bg-blue-400 rounded-full animate-bounce"
                            style={{ animationDelay: "0.1s" }}
                          ></div>
                          <div
                            className="w-2 h-2 bg-blue-400 rounded-full animate-bounce"
                            style={{ animationDelay: "0.2s" }}
                          ></div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>
          </ScrollArea>
        </div>

        {/* Input Area */}
        <div className="bg-white p-6 rounded-b-lg border-t-2 border-blue-100">
          <form onSubmit={handleSubmit} className="flex gap-4">
            <div className="flex-1 relative">
              <Input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Tanyakan strategi trading, analisis teknikal, risk management, atau tips profesional lainnya..."
                disabled={isLoading}
                className="h-14 border-2 border-blue-200 focus:border-blue-400 focus:ring-blue-400 text-gray-800 text-base placeholder:text-gray-500 pr-12 rounded-xl"
              />
              <MessageCircle className="absolute right-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-blue-400" />
            </div>
            <Button
              type="submit"
              disabled={isLoading || !input.trim()}
              className="bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white h-14 px-8 shadow-lg hover:shadow-xl transition-all duration-300 rounded-xl text-base font-semibold"
            >
              <Send className="w-5 h-5 mr-2" />
              Kirim
            </Button>
          </form>

          <div className="mt-4 text-center">
            <p className="text-sm text-gray-600">
              💡 <strong>Tips:</strong> Semakin spesifik pertanyaan Anda, semakin detail dan actionable jawaban yang
              akan diberikan
            </p>
          </div>
        </div>
      </Card>
    </div>
  )
}
