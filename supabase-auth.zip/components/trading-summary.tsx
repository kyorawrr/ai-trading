"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts"

const data = [
  { name: "Jan", profit: 400000 },
  { name: "Feb", profit: 300000 },
  { name: "Mar", profit: 600000 },
  { name: "Apr", profit: 800000 },
  { name: "May", profit: 500000 },
  { name: "Jun", profit: 900000 },
]

export function TradingSummary() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Performa Trading</CardTitle>
        <CardDescription>Profit/Loss 6 bulan terakhir</CardDescription>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={300}>
          <LineChart data={data}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="name" />
            <YAxis />
            <Tooltip formatter={(value) => [`Rp ${Number(value).toLocaleString("id-ID")}`, "Profit"]} />
            <Line type="monotone" dataKey="profit" stroke="#10b981" strokeWidth={2} dot={{ fill: "#10b981" }} />
          </LineChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  )
}
