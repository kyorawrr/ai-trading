import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { getTradingRecords } from "@/app/actions/trading"
import { Calendar, TrendingUp, TrendingDown, Activity, Clock } from "lucide-react"

export async function TradingRecords() {
  const { data: records, error } = await getTradingRecords()

  if (error) {
    return (
      <Card className="w-full bg-white border-2 border-red-200 shadow-lg">
        <CardHeader className="bg-gradient-to-r from-red-500 to-red-600 text-white rounded-t-lg">
          <CardTitle className="flex items-center gap-2 text-xl font-bold">
            <Calendar className="w-6 h-6" />
            Riwayat Trading
          </CardTitle>
          <CardDescription className="text-red-100 text-base">Error memuat data</CardDescription>
        </CardHeader>
        <CardContent className="p-8">
          <div className="text-center py-8 text-red-600">
            <p className="text-lg font-semibold">Gagal memuat data trading.</p>
            <p className="text-base">Silakan refresh halaman.</p>
          </div>
        </CardContent>
      </Card>
    )
  }

  // Calculate quick stats
  const totalTrades = records?.length || 0
  const winningTrades = records?.filter((r: any) => Number.parseFloat(r.profit_loss) > 0).length || 0
  const winRate = totalTrades > 0 ? (winningTrades / totalTrades) * 100 : 0

  return (
    <Card className="w-full bg-white border-2 border-blue-200 shadow-lg hover:shadow-xl transition-all duration-300">
      <CardHeader className="bg-gradient-to-r from-blue-500 to-blue-600 text-white rounded-t-lg">
        <CardTitle className="flex items-center gap-3 text-xl font-bold">
          <Calendar className="w-6 h-6" />
          Riwayat Trading
          <Badge className="ml-auto bg-white/20 text-white border-0 text-sm font-semibold">{totalTrades} trades</Badge>
        </CardTitle>
        <CardDescription className="text-blue-100 text-base">
          Transaksi terbaru • Win Rate: {winRate.toFixed(1)}%
        </CardDescription>
      </CardHeader>

      <CardContent className="p-6">
        {!records || records.length === 0 ? (
          <div className="text-center py-12">
            <div className="w-20 h-20 bg-gradient-to-r from-blue-500 to-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
              <Activity className="w-10 h-10 text-white" />
            </div>
            <p className="text-gray-800 text-xl font-semibold mb-2">Belum ada data trading</p>
            <p className="text-gray-600 text-base">Mulai catat aktivitas trading Anda!</p>
          </div>
        ) : (
          <div className="space-y-4 max-h-96 overflow-y-auto">
            {records.slice(0, 10).map((record: any) => {
              const profitLoss = Number.parseFloat(record.profit_loss)
              const isProfit = profitLoss >= 0

              return (
                <div
                  key={record.id}
                  className={`p-4 rounded-lg border-2 transition-all duration-300 hover:shadow-md ${
                    isProfit
                      ? "bg-green-50 border-green-200 hover:bg-green-100"
                      : "bg-red-50 border-red-200 hover:bg-red-100"
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <div className={`w-4 h-4 rounded-full ${isProfit ? "bg-green-500" : "bg-red-500"}`}></div>

                      <div className="flex flex-col">
                        <div className="flex items-center gap-2 mb-2">
                          <Badge
                            variant="outline"
                            className={`border-2 text-sm font-semibold ${
                              record.kategori === "harian"
                                ? "bg-blue-100 text-blue-700 border-blue-300"
                                : record.kategori === "mingguan"
                                  ? "bg-purple-100 text-purple-700 border-purple-300"
                                  : "bg-orange-100 text-orange-700 border-orange-300"
                            }`}
                          >
                            {record.kategori === "harian"
                              ? "📅 Harian"
                              : record.kategori === "mingguan"
                                ? "📊 Mingguan"
                                : "📈 Bulanan"}
                          </Badge>

                          {record.symbol && (
                            <span className="text-sm font-bold text-gray-800 bg-gray-200 px-3 py-1 rounded-full">
                              {record.symbol}
                            </span>
                          )}

                          {record.tipe_trade && (
                            <Badge
                              variant="outline"
                              className={`border-2 text-sm font-semibold ${
                                record.tipe_trade === "buy"
                                  ? "bg-green-100 text-green-700 border-green-300"
                                  : "bg-red-100 text-red-700 border-red-300"
                              }`}
                            >
                              {record.tipe_trade === "buy" ? "🟢 BUY" : "🔴 SELL"}
                            </Badge>
                          )}
                        </div>

                        <div className="flex items-center gap-2 text-gray-600">
                          <Clock className="w-4 h-4" />
                          <p className="text-sm font-medium">
                            {new Date(record.tanggal).toLocaleDateString("id-ID", {
                              weekday: "long",
                              year: "numeric",
                              month: "long",
                              day: "numeric",
                            })}
                          </p>
                        </div>

                        {record.catatan && <p className="text-sm text-gray-600 mt-2 max-w-xs">💭 {record.catatan}</p>}
                      </div>
                    </div>

                    <div className="text-right">
                      <div className="flex items-center gap-2 mb-1">
                        {isProfit ? (
                          <TrendingUp className="w-5 h-5 text-green-600" />
                        ) : (
                          <TrendingDown className="w-5 h-5 text-red-600" />
                        )}
                        <div className={`font-bold text-xl ${isProfit ? "text-green-600" : "text-red-600"}`}>
                          {isProfit ? "+" : ""}Rp {profitLoss.toLocaleString("id-ID")}
                        </div>
                      </div>

                      <div className="text-sm text-gray-600 space-y-1">
                        {record.jumlah_lot && <p>📦 {record.jumlah_lot} lot</p>}
                        {record.harga_entry && record.harga_exit && (
                          <p>
                            💹 {record.harga_entry} → {record.harga_exit}
                          </p>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              )
            })}
          </div>
        )}
      </CardContent>
    </Card>
  )
}
