"use client"

import { useState, useTransition } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { addTradingRecord } from "@/app/actions/trading"
import { TrendingUp, DollarSign } from "lucide-react"
import { TooltipProvider } from "@/components/ui/tooltip"

export function TradingForm() {
  const [isPending, startTransition] = useTransition()
  const [kategori, setKategori] = useState("")
  const [tipeTrading, setTipeTrading] = useState("")
  const [profitLossType, setProfitLossType] = useState("")
  const [amount, setAmount] = useState("")

  const handleSubmit = (formData: FormData) => {
    // Calculate final profit/loss based on type
    const baseAmount = Math.abs(Number.parseFloat(amount))
    const finalAmount = profitLossType === "loss" ? -baseAmount : baseAmount

    formData.set("kategori", kategori)
    formData.set("profit_loss", finalAmount.toString())

    if (tipeTrading) {
      formData.set("tipe_trade", tipeTrading)
    }

    startTransition(() => {
      addTradingRecord(formData)
    })
  }

  return (
    <TooltipProvider>
      <Card className="w-full bg-white border-2 border-blue-200 shadow-lg hover:shadow-xl transition-all duration-300">
        <CardHeader className="bg-gradient-to-r from-blue-500 to-blue-600 text-white rounded-t-lg">
          <CardTitle className="flex items-center gap-3 text-xl font-bold">
            <TrendingUp className="w-6 h-6" />
            Input Data Trading
          </CardTitle>
          <CardDescription className="text-blue-100 text-base">
            Catat aktivitas trading harian, mingguan, atau bulanan Anda
          </CardDescription>
        </CardHeader>

        <CardContent className="p-8 space-y-6">
          <form action={handleSubmit} className="space-y-6">
            {/* Row 1: Date and Category */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-3">
                <Label htmlFor="tanggal" className="text-gray-800 font-semibold text-base">
                  Tanggal Trading *
                </Label>
                <Input
                  id="tanggal"
                  name="tanggal"
                  type="date"
                  required
                  className="h-12 border-2 border-blue-200 focus:border-blue-400 focus:ring-blue-400 text-gray-800 text-base"
                />
              </div>

              <div className="space-y-3">
                <Label htmlFor="kategori" className="text-gray-800 font-semibold text-base">
                  Kategori Trading *
                </Label>
                <Select value={kategori} onValueChange={setKategori} required>
                  <SelectTrigger className="h-12 border-2 border-blue-200 focus:ring-blue-400 text-gray-800 text-base">
                    <SelectValue placeholder="Pilih kategori trading" />
                  </SelectTrigger>
                  <SelectContent className="bg-white border-blue-200">
                    <SelectItem value="harian" className="text-gray-800 hover:bg-blue-50 text-base py-3">
                      📅 Trading Harian
                    </SelectItem>
                    <SelectItem value="mingguan" className="text-gray-800 hover:bg-blue-50 text-base py-3">
                      📊 Trading Mingguan
                    </SelectItem>
                    <SelectItem value="bulanan" className="text-gray-800 hover:bg-blue-50 text-base py-3">
                      📈 Trading Bulanan
                    </SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Row 2: Symbol and Trade Type */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-3">
                <Label htmlFor="symbol" className="text-gray-800 font-semibold text-base">
                  Symbol Saham
                </Label>
                <Input
                  id="symbol"
                  name="symbol"
                  placeholder="Contoh: BBRI, TLKM, GOTO"
                  className="h-12 border-2 border-blue-200 focus:border-blue-400 focus:ring-blue-400 text-gray-800 text-base placeholder:text-gray-500"
                />
              </div>

              <div className="space-y-3">
                <Label htmlFor="tipe_trade" className="text-gray-800 font-semibold text-base">
                  Tipe Trading
                </Label>
                <Select value={tipeTrading} onValueChange={setTipeTrading}>
                  <SelectTrigger className="h-12 border-2 border-blue-200 focus:ring-blue-400 text-gray-800 text-base">
                    <SelectValue placeholder="Pilih tipe trading" />
                  </SelectTrigger>
                  <SelectContent className="bg-white border-blue-200">
                    <SelectItem value="buy" className="text-gray-800 hover:bg-blue-50 text-base py-3">
                      🟢 BUY (Beli)
                    </SelectItem>
                    <SelectItem value="sell" className="text-gray-800 hover:bg-blue-50 text-base py-3">
                      🔴 SELL (Jual)
                    </SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Row 3: Trading Details */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="space-y-3">
                <Label htmlFor="jumlah_lot" className="text-gray-800 font-semibold text-base">
                  Jumlah Lot
                </Label>
                <Input
                  id="jumlah_lot"
                  name="jumlah_lot"
                  type="number"
                  placeholder="1"
                  min="0"
                  className="h-12 border-2 border-blue-200 focus:border-blue-400 focus:ring-blue-400 text-gray-800 text-base placeholder:text-gray-500"
                />
              </div>

              <div className="space-y-3">
                <Label htmlFor="harga_entry" className="text-gray-800 font-semibold text-base">
                  Harga Entry
                </Label>
                <Input
                  id="harga_entry"
                  name="harga_entry"
                  type="number"
                  step="0.01"
                  placeholder="4500"
                  min="0"
                  className="h-12 border-2 border-blue-200 focus:border-blue-400 focus:ring-blue-400 text-gray-800 text-base placeholder:text-gray-500"
                />
              </div>

              <div className="space-y-3">
                <Label htmlFor="harga_exit" className="text-gray-800 font-semibold text-base">
                  Harga Exit
                </Label>
                <Input
                  id="harga_exit"
                  name="harga_exit"
                  type="number"
                  step="0.01"
                  placeholder="4600"
                  min="0"
                  className="h-12 border-2 border-blue-200 focus:border-blue-400 focus:ring-blue-400 text-gray-800 text-base placeholder:text-gray-500"
                />
              </div>
            </div>

            {/* Row 4: Profit/Loss Section */}
            <div className="bg-blue-50 p-6 rounded-lg border-2 border-blue-200">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-3">
                  <Label htmlFor="profit_loss_type" className="text-gray-800 font-semibold text-base">
                    Hasil Trading *
                  </Label>
                  <Select value={profitLossType} onValueChange={setProfitLossType} required>
                    <SelectTrigger className="h-12 border-2 border-blue-300 focus:ring-blue-400 bg-white text-gray-800 text-base">
                      <SelectValue placeholder="Pilih hasil trading" />
                    </SelectTrigger>
                    <SelectContent className="bg-white border-blue-200">
                      <SelectItem value="profit" className="text-green-700 hover:bg-green-50 text-base py-3">
                        💰 PROFIT (Untung)
                      </SelectItem>
                      <SelectItem value="loss" className="text-red-700 hover:bg-red-50 text-base py-3">
                        📉 LOSS (Rugi)
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-3">
                  <Label htmlFor="amount" className="text-gray-800 font-semibold text-base">
                    Jumlah (Rp) *
                  </Label>
                  <div className="relative">
                    <DollarSign className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-500" />
                    <Input
                      id="amount"
                      value={amount}
                      onChange={(e) => setAmount(e.target.value)}
                      type="number"
                      step="0.01"
                      placeholder="150000"
                      required
                      min="0"
                      className="h-12 pl-10 pr-12 border-2 border-blue-300 focus:border-blue-400 focus:ring-blue-400 bg-white text-gray-800 text-base placeholder:text-gray-500"
                    />
                    <span className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-600 font-medium">
                      Rp
                    </span>
                  </div>
                  {amount && profitLossType && (
                    <p
                      className={`text-sm font-medium ${profitLossType === "profit" ? "text-green-600" : "text-red-600"}`}
                    >
                      {profitLossType === "profit" ? "✅" : "❌"} {profitLossType === "profit" ? "Profit" : "Loss"}: Rp{" "}
                      {Number.parseFloat(amount || "0").toLocaleString("id-ID")}
                    </p>
                  )}
                </div>
              </div>
            </div>

            {/* Row 5: Notes */}
            <div className="space-y-3">
              <Label htmlFor="catatan" className="text-gray-800 font-semibold text-base">
                Catatan Trading
              </Label>
              <Textarea
                id="catatan"
                name="catatan"
                placeholder="Strategi yang digunakan, analisa market, atau catatan penting lainnya..."
                rows={4}
                className="border-2 border-blue-200 focus:border-blue-400 focus:ring-blue-400 text-gray-800 text-base placeholder:text-gray-500 resize-none"
              />
            </div>

            {/* Submit Button */}
            <Button
              type="submit"
              className="w-full h-14 bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white text-lg font-semibold shadow-lg hover:shadow-xl transition-all duration-300"
              disabled={isPending || !kategori || !profitLossType || !amount}
            >
              {isPending ? (
                <div className="flex items-center gap-3">
                  <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                  Menyimpan Data...
                </div>
              ) : (
                <div className="flex items-center gap-3">
                  <TrendingUp className="w-5 h-5" />
                  Simpan Data Trading
                </div>
              )}
            </Button>
          </form>
        </CardContent>
      </Card>
    </TooltipProvider>
  )
}
